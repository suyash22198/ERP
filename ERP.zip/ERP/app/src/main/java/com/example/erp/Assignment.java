package com.example.erp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class Assignment extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((Main_Screen) getActivity()).getSupportActionBar().setTitle("Assignment");
        View view = inflater.inflate(R.layout.fragment_assignment, container, false);



        return view;
    }
}