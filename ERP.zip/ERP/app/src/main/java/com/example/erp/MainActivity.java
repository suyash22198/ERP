package com.example.erp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    static int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CardView card_login=findViewById(R.id.card_login);
        RelativeLayout first_page=findViewById(R.id.first_page);
        TextInputEditText num_input=findViewById(R.id.num_input);
        Button send_otp=findViewById(R.id.send_otp_btn);


        PinView otp=findViewById(R.id.otp_num);
        Button verfy_btn=findViewById(R.id.verfy_btn);
        TextView otp_txt=findViewById(R.id.otp_txt);
        TextView resend_btn=findViewById(R.id.resend_otp_btn);
        TextView change_num=findViewById(R.id.change_num_btn);
        TextView resend_counter=findViewById(R.id.resend_counter);




        send_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (num_input.getText().toString().length()!=10)
                {
                    Toast.makeText(MainActivity.this,"Must 10 digit only",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    String set_otp_txt="Enter  digit code sent to you at " + num_input.getText().toString();
                    otp_txt.setText(set_otp_txt);
                    otp.setText("");
                    card_login.setVisibility(View.VISIBLE);
                    first_page.setVisibility(View.GONE);

                }
            }
        });

        verfy_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (otp.getText().toString().length()!=4)
                {
                    Toast.makeText(MainActivity.this,"Enter all digits",Toast.LENGTH_SHORT).show();
                }
                else
                    {
                        Toast.makeText(MainActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(MainActivity.this,Main_Screen.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                }
            }
        });
        resend_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i++;
                if (i>3)
                {
                    Toast.makeText(MainActivity.this,"Limit exceed to resend",Toast.LENGTH_SHORT).show();
                }
                else{
                    resend_counter.setVisibility(View.VISIBLE);
                    resend_counter.setText(i+"/3");
                }

            }
        });

        change_num.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resend_counter.setVisibility(View.GONE);
                num_input.setText("");
                i=0;
                first_page.setVisibility(View.VISIBLE);
                card_login.setVisibility(View.GONE);
            }
        });
    }
}