package com.example.erp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Main_Screen extends AppCompatActivity {
    LinearLayout home,report,notify,profile;
    ImageView home_i,report_i,notify_i,profile_i;
    TextView home_t,report_t,notify_t,profile_t;

    int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        replacefragment(new Frag1());

        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawerLayout=findViewById(R.id.Drawer);
        ActionBarDrawerToggle actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.app_name,R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        home_t=findViewById(R.id.home_t);
        report_t=findViewById(R.id.report_t);
        notify_t=findViewById(R.id.notification_t);
        profile_t=findViewById(R.id.profile_t);



        home=findViewById(R.id.home_btn);
        report=findViewById(R.id.report_btn);
        notify=findViewById(R.id.notification_btn);
        profile=findViewById(R.id.profile_btn);


        home_i=findViewById(R.id.home_i);
        report_i=findViewById(R.id.report_i);
        notify_i=findViewById(R.id.notification_i);
        profile_i = findViewById(R.id.profile_i);



        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                clearimage();
                getSupportActionBar().setTitle("Dashboard");
                home_t.setTextColor(getResources().getColor(R.color.alter));
                home_i.setImageResource(R.drawable.home_red);
                replacefragment(new Frag1());

            }


        });

        report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearimage();
                getSupportActionBar().setTitle("Report");
                report_t.setTextColor(getResources().getColor(R.color.alter));
                report_i.setImageResource(R.drawable.report_red);
                replacefragment(new Frag2());

            }


        });

        notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearimage();
                getSupportActionBar().setTitle("Notify");
                notify_t.setTextColor(getResources().getColor(R.color.alter));
                notify_i.setImageResource(R.drawable.notification_red);
                replacefragment(new Frag3());

            }


        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportActionBar().setTitle("Profile");
                clearimage();
                profile_t.setTextColor(getResources().getColor(R.color.alter));
                profile_i.setImageResource(R.drawable.person_red);
                replacefragment(new Frag4());

            }


        });



    }

    private void replacefragment(Fragment frag) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.Frame, frag);
        fragmentTransaction.commit();
    }

    private void clearimage() {
        home_t.setTextColor(getResources().getColor(R.color.white));
        report_t.setTextColor(getResources().getColor(R.color.white));
        notify_t.setTextColor(getResources().getColor(R.color.white));
        profile_t.setTextColor(getResources().getColor(R.color.white));

        home_i.setImageResource(R.drawable.ic_baseline_home_24);
        report_i.setImageResource(R.drawable.ic_baseline_library_books_24);
        notify_i.setImageResource(R.drawable.ic_baseline_notifications_none_24);
        profile_i.setImageResource(R.drawable.ic_baseline_person_24);
    }


}