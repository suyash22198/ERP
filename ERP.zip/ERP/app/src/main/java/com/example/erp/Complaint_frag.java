package com.example.erp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public
class Complaint_frag extends Fragment {

    String spinner_chose;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((Main_Screen) getActivity()).getSupportActionBar().setTitle("Complaint");

        View view=inflater.inflate(R.layout.fragment_complaint_frag, container, false);

        String [] spin={"Select one","Technical","Faculty","Managment"};
        Spinner spinner= (Spinner) view.findViewById(R.id.spinner_t);
        ArrayAdapter ad=new ArrayAdapter(getActivity(), R.layout.spinner_item,spin);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(ad);

        TextInputEditText problem=(TextInputEditText) view.findViewById(R.id.content_e);
        EditText name_e=(EditText) view.findViewById(R.id.name_e);
        EditText subject_e=(EditText) view.findViewById(R.id.subject_e);
        Button complaint_btn=(Button) view.findViewById(R.id.Complaint_submit_btn);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getActivity(),spin[position],Toast.LENGTH_SHORT).show();
                spinner_chose = spin[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });



        complaint_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name_e.getText().toString().isEmpty() || subject_e.getText().toString().isEmpty() || spinner_chose==spin[0] || problem.getText().toString().isEmpty()){
                    Toast.makeText(getActivity(),"Please fill all Fields",Toast.LENGTH_SHORT);
                }
                else{
                    Toast.makeText(getActivity(),"Done",Toast.LENGTH_SHORT);
                    FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.Frame,new Frag1());
                    fragmentTransaction.commit();
                }
            }
        });


        return view;
    }
}