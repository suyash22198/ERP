package com.example.erp;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;


public class Fees_frag extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        ((Main_Screen) getActivity()).getSupportActionBar().setTitle("Fees");
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_fees_frag, container, false);

        RelativeLayout fee_info=(RelativeLayout) view.findViewById(R.id.fee_info);
        Button submit_btn=(Button) view.findViewById(R.id.Fee_submit_btn);
        Button prev_btn=(Button) view.findViewById(R.id.Fee_previous_btn);
        CardView fee_amo_card=(CardView) view.findViewById(R.id.fee_ammount_card);
        GridLayout fee_grid=(GridLayout) view.findViewById(R.id.paid_v) ;

        prev_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                    fee_info.setVisibility(View.GONE);
                    fee_grid.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(),"Fetching records",Toast.LENGTH_SHORT).show();
                    fee_amo_card.setVisibility(View.VISIBLE);


            }
        });

        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    fee_grid.setVisibility(View.GONE);
                    fee_info.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(),"Fee Deposited",Toast.LENGTH_SHORT).show();
                    fee_amo_card.setVisibility(View.VISIBLE);


            }
        });

        Button fee_depo_btn=(Button) view.findViewById(R.id.fee_depo_btn);
        fee_depo_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),"Fee Deposited",Toast.LENGTH_SHORT).show();
                fee_amo_card.setVisibility(View.GONE);
                fee_info.setVisibility(View.GONE);
            }
        });



        return view;
    }
}