    package com.example.erp;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


public class Frag1 extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_frag1, container, false);
        // Inflate the layout for this fragment
        CardView attendance_card=(CardView) view.findViewById(R.id.attendance);
        CardView complaint_card=(CardView) view.findViewById(R.id.complaint);
        CardView feedback_card=(CardView) view.findViewById(R.id.feedback_card);
        CardView fees_card=(CardView) view.findViewById(R.id.fees_card);
        CardView planner_card=(CardView) view.findViewById(R.id.planner_card);
        CardView exam_form=(CardView) view.findViewById(R.id.exam_form);
        CardView assignment_card=(CardView) view.findViewById(R.id.assigment);

        exam_form.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                replacefragment(new Exam_form());
            }
        });


        planner_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                replacefragment(new Planner_frag());
            }
        });


        fees_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                replacefragment(new Fees_frag());
            }
        });

        attendance_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),"Attendance",Toast.LENGTH_SHORT).show();
                replacefragment(new Attendance_frag());
//                Intent intent=new Intent(getActivity(),Attendance.class);
//                startActivity(intent);

            }
        });

        complaint_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),"Complaint",Toast.LENGTH_SHORT).show();
                replacefragment(new Complaint_frag());
            }
        });
        feedback_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),"Feedback",Toast.LENGTH_SHORT).show();
                replacefragment(new Feedback_frag());
            }
        });
        assignment_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),"Assignment",Toast.LENGTH_SHORT).show();
                replacefragment(new Assignment());
            }
        });







        return view;
    }

    private void replacefragment(Fragment frag) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.Frame, frag);
        fragmentTransaction.commit();
    }



}