package com.example.erp;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.GridLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;


public class Attendance_frag extends Fragment {

    String spinner_choose;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_attendance_frag, container, false);
        ((Main_Screen)getActivity()).getSupportActionBar().setTitle("Attendance");
        TextInputLayout attendance_date=(TextInputLayout) view.findViewById(R.id.atte_date);

        TextView jan=(TextView) view.findViewById(R.id.january);
        CardView jan_card=(CardView) view.findViewById(R.id.jan_attendance_card);
        GridLayout gjan=(GridLayout) view.findViewById(R.id.attendance_jan);

        TextView feb=(TextView) view.findViewById(R.id.february);
        CardView feb_card=(CardView) view.findViewById(R.id.feb_attendance_card);
        GridLayout gfeb=(GridLayout) view.findViewById(R.id.attendance_feb);

        TextView mar=(TextView) view.findViewById(R.id.march);
        CardView mar_card=(CardView) view.findViewById(R.id.mar_attendance_card);
        GridLayout gmar=(GridLayout) view.findViewById(R.id.attendance_mar);

        TextView apr=(TextView) view.findViewById(R.id.april);
        CardView apr_card=(CardView) view.findViewById(R.id.apr_attendance_card);
        GridLayout gapr=(GridLayout) view.findViewById(R.id.attendance_apr);

        TextView may=(TextView) view.findViewById(R.id.may);
        CardView may_card=(CardView) view.findViewById(R.id.may_attendance_card);
        GridLayout gmay=(GridLayout) view.findViewById(R.id.attendance_may);

        TextView jun=(TextView) view.findViewById(R.id.june);
        CardView jun_card=(CardView) view.findViewById(R.id.jun_attendance_card);
        GridLayout gjun=(GridLayout) view.findViewById(R.id.attendance_jun);

        TextView jul=(TextView) view.findViewById(R.id.july);
        CardView jul_card=(CardView) view.findViewById(R.id.jul_attendance_card);
        GridLayout gjul=(GridLayout) view.findViewById(R.id.attendance_jul);

        TextView aug=(TextView) view.findViewById(R.id.august);
        CardView aug_card=(CardView) view.findViewById(R.id.aug_attendance_card);
        GridLayout gaug=(GridLayout) view.findViewById(R.id.attendance_aug);

        TextView sep=(TextView) view.findViewById(R.id.september);
        CardView sep_card=(CardView) view.findViewById(R.id.sep_attendance_card);
        GridLayout gsep=(GridLayout) view.findViewById(R.id.attendance_sep);

        TextView oct=(TextView) view.findViewById(R.id.october);
        CardView oct_card=(CardView) view.findViewById(R.id.oct_attendance_card);
        GridLayout goct=(GridLayout) view.findViewById(R.id.attendance_oct);

        TextView nov=(TextView) view.findViewById(R.id.november);
        CardView nov_card=(CardView) view.findViewById(R.id.nov_attendance_card);
        GridLayout gnov=(GridLayout) view.findViewById(R.id.attendance_nov);

        TextView dec=(TextView) view.findViewById(R.id.december);
        CardView dec_card=(CardView) view.findViewById(R.id.dec_attendance_card);
        GridLayout gdec=(GridLayout) view.findViewById(R.id.attendance_dec);



        DatePicker calendar = (DatePicker) view.findViewById(R.id.calendarView);

        attendance_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.setVisibility(view.VISIBLE);

            }
        });

        Spinner spinner= (Spinner) view.findViewById(R.id.select_month);
        String [] item={"Select month","January","February","March","April","May","June","July","August","September","October","November","December"};
        ArrayAdapter ad=new ArrayAdapter(getActivity(),R.layout.spinner_item,item);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(ad);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinner_choose = item[position];
                Toast.makeText(getActivity(),spinner_choose,Toast.LENGTH_SHORT).show();
                if (spinner_choose=="January")
                {
                    clear_visibility();
                    jan.setVisibility(view.VISIBLE);
                    jan_card.setVisibility(view.VISIBLE);
                    gjan.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="February")
                {
                    clear_visibility();
                    feb.setVisibility(view.VISIBLE);
                    feb_card.setVisibility(view.VISIBLE);
                    gfeb.setVisibility(view.VISIBLE);
                }

                else if (spinner_choose=="March")
                {
                    clear_visibility();
                    mar.setVisibility(view.VISIBLE);
                    mar_card.setVisibility(view.VISIBLE);
                    gmar.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="April")
                {
                    clear_visibility();
                    apr.setVisibility(view.VISIBLE);
                    apr_card.setVisibility(view.VISIBLE);
                    gapr.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="May")
                {
                    clear_visibility();
                    may.setVisibility(view.VISIBLE);
                    may_card.setVisibility(view.VISIBLE);
                    gmay.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="June")
                {
                    clear_visibility();
                    jun.setVisibility(view.VISIBLE);
                    jun_card.setVisibility(view.VISIBLE);
                    gjun.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="July")
                {
                    clear_visibility();
                    jul.setVisibility(view.VISIBLE);
                    jul_card.setVisibility(view.VISIBLE);
                    gjul.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="August")
                {
                    clear_visibility();
                    aug.setVisibility(view.VISIBLE);
                    aug_card.setVisibility(view.VISIBLE);
                    gaug.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="September")
                {
                    clear_visibility();
                    sep.setVisibility(view.VISIBLE);
                    sep_card.setVisibility(view.VISIBLE);
                    gsep.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="October")
                {
                    clear_visibility();
                    oct.setVisibility(view.VISIBLE);
                    oct_card.setVisibility(view.VISIBLE);
                    goct.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="November")
                {
                    clear_visibility();
                    nov.setVisibility(view.VISIBLE);
                    nov_card.setVisibility(view.VISIBLE);
                    gnov.setVisibility(view.VISIBLE);
                }
                else if (spinner_choose=="December")
                {
                    clear_visibility();
                    dec.setVisibility(view.VISIBLE);
                    dec_card.setVisibility(view.VISIBLE);
                    gdec.setVisibility(view.VISIBLE);
                }


            }

            private void clear_visibility() {
                attendance_date.setVisibility(view.VISIBLE);

                jan.setVisibility(view.GONE);
                jan_card.setVisibility(view.GONE);
                gjan.setVisibility(view.GONE);

                feb.setVisibility(view.GONE);
                feb_card.setVisibility(view.GONE);
                gfeb.setVisibility(view.GONE);

                mar.setVisibility(view.GONE);
                mar_card.setVisibility(view.GONE);
                gmar.setVisibility(view.GONE);

                apr.setVisibility(view.GONE);
                apr_card.setVisibility(view.GONE);
                gapr.setVisibility(view.GONE);

                may.setVisibility(view.GONE);
                may_card.setVisibility(view.GONE);
                gmay.setVisibility(view.GONE);

                jun.setVisibility(view.GONE);
                jun_card.setVisibility(view.GONE);
                gjun.setVisibility(view.GONE);

                jul.setVisibility(view.GONE);
                jul_card.setVisibility(view.GONE);
                gjul.setVisibility(view.GONE);

                aug.setVisibility(view.GONE);
                aug_card.setVisibility(view.GONE);
                gaug.setVisibility(view.GONE);

                sep.setVisibility(view.GONE);
                sep_card.setVisibility(view.GONE);
                gsep.setVisibility(view.GONE);

                oct.setVisibility(view.GONE);
                oct_card.setVisibility(view.GONE);
                goct.setVisibility(view.GONE);

                nov.setVisibility(view.GONE);
                nov_card.setVisibility(view.GONE);
                gnov.setVisibility(view.GONE);

                dec.setVisibility(view.GONE);
                dec_card.setVisibility(view.GONE);
                gdec.setVisibility(view.GONE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        return view;
    }


}