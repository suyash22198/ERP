package com.example.adminpannel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ImageView imageView=findViewById(R.id.home);
        ImageView imageView1=findViewById(R.id.student);
        ImageView imageView2=findViewById(R.id.fee);
        ImageView imageView3=findViewById(R.id.profile);


        replacefragment(new fragment1());
        

   
}

    private void replacefragment(Fragment fragment1) {
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.frame,fragment1);
        fragmentTransaction.commit();
    }
}