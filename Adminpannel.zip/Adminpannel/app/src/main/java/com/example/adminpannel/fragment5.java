package com.example.adminpannel;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;


public class fragment5 extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_fragment5, container, false);
        String []year={"select anyone","1st year","2nd year","3rd year","4th year"};
        Spinner year_spinner=(Spinner) view.findViewById(R.id.year);
        ArrayAdapter ad_year= new ArrayAdapter(getActivity(),R.layout.support_simple_spinner_dropdown_item,year);
        ad_year.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        year_spinner.setAdapter(ad_year);


        String []stream={"select anyone","Physics","Python","DBMS","Java"};
        Spinner stream_spinner=(Spinner)view.findViewById(R.id.stream);
        ArrayAdapter ad_stream= new ArrayAdapter(getActivity(),R.layout.support_simple_spinner_dropdown_item,stream);
        ad_stream.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stream_spinner.setAdapter(ad_stream);



        return view;

    }
}